# Traffic Flow Analysis – 3-Lane Vehicle Counting (YOLOv8 + Tracking)

This repo contains a complete solution that **downloads a YouTube traffic video**, detects and tracks vehicles, and **counts them per lane** with an overlaid output video and a CSV export.

## Features (mapped to assignment)
- **Video Dataset**: Downloads and processes the required video (`MNn9qKG2UFI`) inside the script.
- **Vehicle Detection**: Uses pre-trained COCO **YOLOv8** (Ultralytics).
- **Lane Definition & Counting**: 3 lanes (vertical bands by default) with separate counts.
- **Vehicle Tracking**: Lightweight IOU-based tracker that maintains IDs and prevents duplicate counts.
- **Real-time**: Uses `yolov8n.pt`, optional frame skipping, and fused model for speed.
- **Outputs**:
  - `counts.csv` with **VehicleID, Lane, Frame, Timestamp**.
  - `overlay_output.mp4` with lanes and live counts.
  - `summary.txt` with total counts per lane.

> The on-screen look & feel follows the aesthetic of the reference video you shared (lane overlays and live counters).

## Quickstart

```bash
# 1) Create and activate a virtual env (recommended)
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# 2) Install requirements
pip install -r requirements.txt

# 3) Run (CPU example)
python src/main.py --output_dir outputs

# Run on GPU if you have CUDA
python src/main.py --device 0
```

> If `pytube` fails due to upstream changes, the script automatically tries `yt-dlp`.  
> If both fail, download the video manually and place it at `outputs/input.mp4` before running again.

## Lanes: customizing to your footage

By default, lanes are **three vertical bands** across the bottom 70% of the frame.  
To fine-tune lanes for a different road geometry, provide a JSON file via `--lanes_json` with **three polygons** (each a list of `(x,y)` points):

```json
[
  [[100, 300], [400, 300], [400, 720], [100, 720]],
  [[400, 300], [800, 300], [800, 720], [400, 720]],
  [[800, 300], [1280, 300], [1280, 720], [800, 720]]
]
```

Then run:
```bash
python src/main.py --lanes_json lanes.json
```

## CSV Schema

`counts.csv` (created inside `outputs/`) has columns:
```
VehicleID,Lane,Frame,Timestamp(s)
```

Each row corresponds to **one vehicle** when it **crosses** the horizontal counting line (set at 60% of frame height) inside a lane region.

## Tips for Accuracy & Speed

- Use `--conf 0.35` to suppress weak detections.
- Set `--frame_skip 1` or `2` on slower CPUs.
- For better tracking across occlusions, you can swap the simple IOU tracker for **SORT/DeepSORT** later.
- Prefer GPU (`--device 0`) for real-time performance.

## Creating a 1–2 minute demo video

- The script **already saves** `overlay_output.mp4`. Trim to 60–120s in any editor or with FFmpeg:
```bash
ffmpeg -ss 00:00:10 -i outputs/overlay_output.mp4 -t 00:01:30 -c copy outputs/demo_trimmed.mp4
```

## Repo structure

```
traffic_flow_analysis_project/
├─ requirements.txt
├─ README.md
└─ src/
   └─ main.py
```

## License
MIT

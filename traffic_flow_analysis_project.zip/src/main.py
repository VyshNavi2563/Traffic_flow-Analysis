#!/usr/bin/env python3
"""
Traffic Flow Analysis - Vehicle Counting per Lane with Tracking

Meets requirements from the assignment PDF:
- Downloads the specified YouTube video (MNn9qKG2UFI) within the script
- Uses a pre-trained COCO model (YOLOv8) for vehicle detection
- Defines 3 lanes and counts vehicles separately per lane
- Tracks vehicles across frames to avoid duplicate counts (simple IOU tracker)
- Optimized for near real-time on standard hardware (use YOLOv8n by default, frame skipping optional)
- Outputs:
  * CSV with VehicleID, Lane, Frame, Timestamp
  * Overlaid video with lanes and live counts
  * Summary totals per lane at the end

Usage:
    python main.py --output_dir outputs/
Optional:
    python main.py --video_url https://www.youtube.com/watch?v=MNn9qKG2UFI
    python main.py --model yolov8n.pt --conf 0.25 --device 0

Notes:
- For best results, install GPU-enabled PyTorch, and set --device 0
- Lanes are automatically defined as 3 vertical bands across the region of interest.
  You can override with a JSON lane config (see README).
"""
import argparse
import os
import cv2
import math
import time
import sys
import csv
import tempfile
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Optional

# ---- Optional downloader: pytube ----
def download_youtube_video(url: str, target_path: str) -> str:
    """
    Download a YouTube video to target_path (mp4). Tries pytube then yt-dlp.
    Returns the local file path.
    """
    try:
        from pytube import YouTube
        yt = YouTube(url)
        stream = yt.streams.filter(file_extension="mp4", progressive=True).order_by("resolution").desc().first()
        out_file = stream.download(output_path=os.path.dirname(target_path), filename=os.path.basename(target_path))
        return out_file
    except Exception as e:
        print(f"[download] pytube failed ({e}). Trying yt-dlp...", file=sys.stderr)
        # fallback to yt-dlp if available
        out = target_path
        try:
            import subprocess, shlex
            cmd = f'yt-dlp -f "mp4[height<=720]" -o "{out}" "{url}"'
            print(f"[download] {cmd}")
            subprocess.check_call(cmd, shell=True)
            return out if os.path.exists(out) else out
        except Exception as ee:
            print(f"[download] yt-dlp also failed ({ee}). Please download manually.", file=sys.stderr)
            raise

# ---- Simple IOU tracker (lightweight alternative to SORT) ----
@dataclass
class Track:
    id: int
    bbox: Tuple[float, float, float, float]  # x1,y1,x2,y2
    hits: int = 0
    no_updates: int = 0
    history: List[Tuple[int, Tuple[float,float]]] = field(default_factory=list)  # (frame_idx, centroid)
    counted: bool = False  # whether this track has been counted (crossed the counting line)

class IOUTracker:
    def __init__(self, iou_threshold: float = 0.3, max_age: int = 10):
        self.iou_threshold = iou_threshold
        self.max_age = max_age
        self.tracks: Dict[int, Track] = {}
        self.next_id = 1

    @staticmethod
    def iou(boxA, boxB):
        xA = max(boxA[0], boxB[0])
        yA = max(boxA[1], boxB[1])
        xB = min(boxA[2], boxB[2])
        yB = min(boxA[3], boxB[3])
        inter = max(0, xB - xA) * max(0, yB - yA)
        areaA = (boxA[2]-boxA[0])*(boxA[3]-boxA[1])
        areaB = (boxB[2]-boxB[0])*(boxB[3]-boxB[1])
        union = areaA + areaB - inter + 1e-6
        return inter / union

    @staticmethod
    def centroid(b):
        return ( (b[0]+b[2])/2.0, (b[1]+b[3])/2.0 )

    def update(self, detections: List[Tuple[float,float,float,float]], frame_idx:int):
        # Greedy matching by IOU
        assigned_det = set()
        # 1) try to match existing tracks
        for tid, tr in list(self.tracks.items()):
            best_iou, best_j = 0.0, -1
            for j, det in enumerate(detections):
                if j in assigned_det: 
                    continue
                i = self.iou(tr.bbox, det)
                if i > best_iou:
                    best_iou, best_j = i, j
            if best_j >= 0 and best_iou >= self.iou_threshold:
                tr.bbox = detections[best_j]
                tr.hits += 1
                tr.no_updates = 0
                tr.history.append( (frame_idx, self.centroid(tr.bbox)) )
                assigned_det.add(best_j)
            else:
                tr.no_updates += 1

        # 2) create new tracks from unmatched dets
        for j, det in enumerate(detections):
            if j not in assigned_det:
                t = Track(id=self.next_id, bbox=det, hits=1)
                t.history.append( (frame_idx, self.centroid(det)) )
                self.tracks[self.next_id] = t
                self.next_id += 1

        # 3) remove old tracks
        for tid in list(self.tracks.keys()):
            if self.tracks[tid].no_updates > self.max_age:
                del self.tracks[tid]

        return self.tracks

# ---- Lane utils ----
def point_in_polygon(pt, poly):
    # ray casting algorithm
    x, y = pt
    inside = False
    n = len(poly)
    for i in range(n):
        x1,y1 = poly[i]
        x2,y2 = poly[(i+1)%n]
        cond = ((y1 > y) != (y2 > y)) and (x < (x2-x1)*(y-y1)/(y2-y1+1e-9) + x1)
        if cond: inside = not inside
    return inside

def default_three_lanes(width, height):
    # 3 vertical bands across bottom 70% of the frame
    top = int(0.3*height)
    lane_w = width // 3
    lane1 = [(0, top), (lane_w, top), (lane_w, height), (0, height)]
    lane2 = [(lane_w, top), (2*lane_w, top), (2*lane_w, height), (lane_w, height)]
    lane3 = [(2*lane_w, top), (width, top), (width, height), (2*lane_w, height)]
    return [lane1, lane2, lane3]

def lane_index_for_point(pt, lanes):
    for idx, poly in enumerate(lanes, start=1):
        if point_in_polygon(pt, poly):
            return idx
    return 0

# ---- Main pipeline ----
def run(args):
    # 1) Download video
    url = args.video_url or "https://www.youtube.com/watch?v=MNn9qKG2UFI"
    os.makedirs(args.output_dir, exist_ok=True)
    raw_video_path = os.path.join(args.output_dir, "input.mp4")
    if not os.path.exists(raw_video_path):
        print(f"[info] downloading video from {url} ...")
        download_youtube_video(url, raw_video_path)
    else:
        print(f"[info] using existing video: {raw_video_path}")

    # 2) Load detector
    from ultralytics import YOLO
    model = YOLO(args.model)
    model.fuse()
    print(f"[model] loaded {args.model}")

    # 3) Open video IO
    cap = cv2.VideoCapture(raw_video_path)
    assert cap.isOpened(), "Cannot open downloaded video"
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out_path = os.path.join(args.output_dir, "overlay_output.mp4")
    writer = cv2.VideoWriter(out_path, fourcc, fps, (w, h))

    # 4) Prepare lanes & counting line
    lanes = default_three_lanes(w, h) if not args.lanes_json else json.load(open(args.lanes_json))
    # counting line y: lower half
    count_line_y = int(0.6*h)

    # 5) tracking + counting
    tracker = IOUTracker(iou_threshold=args.iou, max_age=args.max_age)
    vehicle_classes = {2,3,5,7}  # COCO: car(2), motorcycle(3), bus(5), truck(7)
    csv_path = os.path.join(args.output_dir, "counts.csv")
    csv_file = open(csv_path, "w", newline="")
    csv_writer = csv.writer(csv_file)
    csv_writer.writerow(["VehicleID", "Lane", "Frame", "Timestamp(s)"])

    lane_counts = {1:0, 2:0, 3:0}
    prev_centroids = {}  # id -> last centroid for crossing detection

    frame_idx = 0
    t0 = time.time()

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame_idx += 1

        # detection
        if args.frame_skip and frame_idx % (args.frame_skip+1) != 1:
            dets_xyxy = []
        else:
            results = model.predict(frame, conf=args.conf, iou=0.5, verbose=False, device=args.device)
            dets_xyxy = []
            for r in results:
                boxes = r.boxes
                for b in boxes:
                    cls_id = int(b.cls.item())
                    if cls_id in vehicle_classes:
                        x1,y1,x2,y2 = b.xyxy[0].tolist()
                        dets_xyxy.append( (x1,y1,x2,y2) )

        tracks = tracker.update(dets_xyxy, frame_idx)

        # draw lanes
        overlay = frame.copy()
        for idx, poly in enumerate(lanes, start=1):
            cv2.polylines(overlay, [cv2.UMat(np.array(poly, dtype=np.int32))], True, (0,255,0), 2)
            cv2.putText(overlay, f"Lane {idx}: {lane_counts[idx]}", (poly[0][0]+10, poly[0][1]+30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)

        # counting line
        cv2.line(overlay, (0, count_line_y), (w, count_line_y), (255, 255, 0), 2)

        # draw & count per track
        for tid, tr in tracks.items():
            x1,y1,x2,y2 = map(int, tr.bbox)
            cx, cy = IOUTracker.centroid(tr.bbox)
            cx_i, cy_i = int(cx), int(cy)
            # draw bbox + id
            cv2.rectangle(overlay, (x1,y1), (x2,y2), (0, 150, 255), 2)
            cv2.putText(overlay, f"ID {tid}", (x1, y1-7), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 150, 255), 2)
            cv2.circle(overlay, (cx_i, cy_i), 4, (0, 150, 255), -1)

            # lane for current centroid
            lane_idx = lane_index_for_point((cx, cy), lanes)

            # crossing detection: from above to below the counting line, count once
            prev_cy = prev_centroids.get(tid, cy)
            if (prev_cy < count_line_y) and (cy >= count_line_y) and (not tr.counted) and (lane_idx in lane_counts):
                lane_counts[lane_idx] += 1
                tr.counted = True
                # write CSV
                timestamp_s = frame_idx / fps
                csv_writer.writerow([tid, lane_idx, frame_idx, round(timestamp_s, 3)])

            prev_centroids[tid] = cy

        # HUD
        elapsed = time.time() - t0
        fps_live = frame_idx / max(elapsed, 1e-6)
        cv2.putText(overlay, f"FPS: {fps_live:.1f}", (15, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)

        writer.write(overlay)

    # end
    cap.release()
    writer.release()
    csv_file.close()

    # Summary print & save
    summary_txt = os.path.join(args.output_dir, "summary.txt")
    with open(summary_txt, "w") as f:
        for ln in [1,2,3]:
            line = f"Lane {ln} total: {lane_counts[ln]}"
            print(line)
            f.write(line + "\n")
    print(f"[done] overlay video: {out_path}")
    print(f"[done] CSV: {csv_path}")
    print(f"[done] Summary: {summary_txt}")

if __name__ == "__main__":
    import numpy as np
    parser = argparse.ArgumentParser()
    parser.add_argument("--video_url", type=str, default="https://www.youtube.com/watch?v=MNn9qKG2UFI", help="YouTube URL to download and process")
    parser.add_argument("--output_dir", type=str, default="outputs", help="Where to save outputs")
    parser.add_argument("--model", type=str, default="yolov8n.pt", help="Ultralytics YOLOv8 model name or path")
    parser.add_argument("--conf", type=float, default=0.25, help="Detection confidence threshold")
    parser.add_argument("--device", type=str, default="cpu", help="'cpu' or CUDA device index like '0'")
    parser.add_argument("--iou", type=float, default=0.3, help="IOU threshold for tracker assignment")
    parser.add_argument("--max_age", type=int, default=10, help="Max frames to keep unmatched track alive")
    parser.add_argument("--frame_skip", type=int, default=0, help="Skip N frames between inferences to speed up")
    parser.add_argument("--lanes_json", type=str, default="", help="Optional JSON file with 3 polygons [[(x,y),...], ...]")
    args = parser.parse_args()
    run(args)
